<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JamKerja extends Model
{
    protected $table = 'jam_kerja';
    protected $guarded = [];
}
