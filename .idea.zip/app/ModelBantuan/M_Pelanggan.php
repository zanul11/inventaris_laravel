<?php

namespace App\ModelBantuan;

use Illuminate\Database\Eloquent\Model;

class M_Pelanggan extends Model
{
    protected $table = 'pbaru.m_pelanggan';
    protected $guarded = [];
}
