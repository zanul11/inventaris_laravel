<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LogPeralatanMasuk extends Model
{
    protected $table = 'log_peralatan';
    protected $guarded = [];
}
