<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JenisAkunting extends Model
{
    protected $table = 'jenis_akunting';
    protected $guarded = [];
}
