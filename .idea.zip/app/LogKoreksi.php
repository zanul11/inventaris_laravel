<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LogKoreksi extends Model
{
    protected $table = 'log_koreksi';
    protected $guarded = [];
}
