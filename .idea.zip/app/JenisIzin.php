<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JenisIzin extends Model
{
    protected $table = 'jenis_izin';
    protected $guarded = [];
}
