<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Libur extends Model
{
    protected $table = 'tanggal_libur';
    protected $guarded = [];
}
