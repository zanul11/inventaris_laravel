

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('plugins_styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a>Setup</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/user')); ?>">User</a></li>
        <li class="breadcrumb-item"><a>Tambah Data</a></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header">User <small>Tambah Data</small></h1>

    <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
        <!-- begin panel-heading -->
        <div class="panel-heading ui-sortable-handle">
            <h4 class="panel-title">Form Tambah Data</h4>

        </div>
        <form method="POST" action="<?php echo e(($action=='add')?'/user':'/user/'.$user->id); ?>">
            <?php echo csrf_field(); ?>
            <?php if($action=='/user/'.$user->id): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <div class="panel-body">
                <div class="row width-full">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="control-label">Nama</label>
                            <input type="text" class="form-control" style="display: block;" value="<?php echo e(($action!='add')?$user->nama:''); ?>" name="nama" placeholder="Nama..." required>
                        </div>
                        <div class="form-group">
                            <label class="control-label">TIPE</label>
                            <select class="select2 show-tick form-control required" name="tipe" data-style="btn-primary" required>
                                <option value="2" <?php echo e((old('tipe', $user->type)==2)?'selected':''); ?>>USER</option>
                                <option value="3" <?php echo e((old('tipe', $user->type)==3)?'selected':''); ?>>KEPALA</option>
                                <option value="1" <?php echo e((old('tipe', $user->type)==1)?'selected':''); ?>>SUPER ADMIN</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Username (tanpa spasi)</label>
                            <input type="text" class="form-control" style="display: block;" value="<?php echo e(($action!='add')?$user->user:''); ?>" name="user" placeholder="Username..." required <?php echo e(($action!='add')?'readonly':''); ?>>
                        </div>

                        <div class="form-group">
                            <label class="control-label">Kata Sandi</label>
                            <div class="input-group">
                                <input type="password" class="form-control" style="display: block;" name="password" placeholder="Password user..." <?php echo e(($action!='add')?'':'required'); ?>>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="note note-primary">
                            <div class="note-content">
                                <h4><b>Hak Akses</b></h4>
                                <hr>
                                <div class="height-200" style="display: block; position: relative; overflow: auto;">

                                    <div class="col-sm-10">
                                        <div class="row">
                                            <?php if($action=='add'): ?>
                                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($parent->status==1 && $parent->kd_menu!='mn1'): ?>
                                            <div class="col-4">
                                                <label for="<?php echo e($parent->nm_menu); ?>"><b style="font-size: 14px;"><?php echo e($parent->nm_menu); ?></b>
                                                    <?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($child->status==0 AND $child->kd_parent==$parent->kd_menu): ?>
                                                    <div class="hakakses checkbox checkbox-css">
                                                        <input type="checkbox" class="administrator" name="akses[]" id="<?php echo e($child->nm_menu); ?>" value="<?php echo e($child->kd_menu); ?>">
                                                        <label for="<?php echo e($child->nm_menu); ?>"><?php echo e($child->nm_menu); ?>

                                                        </label>
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </label>

                                            </div>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php elseif($action=='/user/' . $user->id): ?>
                                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($parent->status==1): ?>
                                            <div class="col-4">
                                                <label for="<?php echo e($parent->nm_menu); ?>"><b style="font-size: 14px;"><?php echo e($parent->nm_menu); ?></b>
                                                    <?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($child->status==0 AND $child->kd_parent==$parent->kd_menu): ?>
                                                    <?php
                                                    $cek = '';
                                                    ?>
                                                    <div class="hakakses checkbox checkbox-css">
                                                        <?php if(count($menuaktifs)>0): ?>
                                                        <?php $__currentLoopData = $menuaktifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aktif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if( $child->kd_menu==$aktif->kd_menu): ?>
                                                        <?php
                                                        $cek = 'checked';
                                                        ?>
                                                        <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <input type="checkbox" class="administrator" name="akses[]" id="<?php echo e($child->nm_menu); ?>" value="<?php echo e($child->kd_menu); ?>" <?php echo e($cek); ?>>
                                                        <label for="<?php echo e($child->nm_menu); ?>"><?php echo e($child->nm_menu); ?>

                                                        </label>
                                                        <?php else: ?>
                                                        <input type="checkbox" class="administrator" name="akses[]" id="<?php echo e($child->nm_menu); ?>" value="<?php echo e($child->kd_menu); ?>">
                                                        <label for="<?php echo e($child->nm_menu); ?>"><?php echo e($child->nm_menu); ?>

                                                        </label>
                                                        <?php endif; ?>

                                                        <!-- <label class="checkbox checkbox-primary">
                                                <span class="input-span"></span><?php echo e($child->nm_menu); ?></label> -->
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </label>


                                            </div>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <div class="panel-footer">
        <input type="submit" value="Simpan" class="btn btn-success m-r-3">
        <a wire:click="batal" class="btn btn-danger">Batal</a>
    </div>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\inventariss\resources\views/pages/user/create.blade.php ENDPATH**/ ?>