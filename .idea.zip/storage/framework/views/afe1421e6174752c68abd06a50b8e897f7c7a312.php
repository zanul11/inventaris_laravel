

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('plugins_styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<style>
    #fullpage {
        display: none;
        position: absolute;
        z-index: 9999;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background-size: contain;
        background-repeat: no-repeat no-repeat;
        background-position: center center;
        background-color: white;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a>Keuangan</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/pengeluaran')); ?>">PENGELUARAN</a></li>
        <li class="breadcrumb-item"><a>Tambah Data</a></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom">TAMBAH DATA</span> PENGELUARAN</h1>

    <div class="row">
        <div class="<?php echo e((isset($pengeluaran->log))?'col-lg-9':'col-lg-12'); ?>">
            <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                <!-- begin panel-heading -->
                <div class="panel-heading ui-sortable-handle">
                    <h4 class="panel-title">Form Tambah Data</h4>

                </div>
                <form method="POST" action="<?php echo e(($action=='add')?'/pengeluaran':'/pengeluaran/'.$pengeluaran->id); ?>" enctype='multipart/form-data'>
                    <?php echo csrf_field(); ?>
                    <?php if($action!='add'): ?>
                    <?php echo method_field('PUT'); ?>
                    <?php endif; ?>
                    <input type="hidden" value="<?php echo e($action); ?>" name="action" />
                    <div class="panel-body">
                        <div class="row width-full">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="control-label">Jenis Pengeluaran</label>
                                    <select class="select2 show-tick form-control required" name="jenis_akunting_id" data-style="btn-primary" required>
                                        <option value="">Pilih Jenis Pengeluaran</option>
                                        <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dt->id); ?>" <?php echo e((old('jenis_akunting_id',$pengeluaran->jenis_akunting_id??'')==$dt->id)?'selected':''); ?>><?php echo e($dt->jenis); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="control-label">Nama Pengeluaran</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" style="display: block;" value="<?php echo e(old('nama',$pengeluaran->nama??'')); ?>" name="nama" placeholder="Nama Pengeluaran..." required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="control-label">Jumlah</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" style="display: block;" value="<?php echo e(old('jumlah',$pengeluaran->jumlah??'')); ?>" name="jumlah" placeholder="Jumlah/Nilai Pengeluaran..." required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="control-label">Keterangan</label>
                                    <div class="input-group">
                                        <textarea class="form-control" style="display: block;" value="" name="ket"><?php echo e(old('ket',$pengeluaran->ket??'')); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="control-label">File Bukti</label>
                                    <div class="input-group">
                                        <input type="file" class="form-control" onchange="checkFileExtension('file')" id="file" style="display: block;" name="file">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <?php if($action=='edit'): ?>
                                <div class="gallery">
                                    <img src="<?php echo e(asset('uploads/'.$pengeluaran->file)); ?>" height="50px">

                                </div>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                    <div class="panel-footer">
                        <input type="submit" value="Simpan" class="btn btn-success m-r-3">
                        <a wire:click="batal" class="btn btn-danger">Batal</a>
                    </div>
            </div>
        </div>


        <div class="col-lg-3">
            <div class="panel panel-primary" data-sortable-id="form-stuff-1">
                <!-- begin panel-heading -->
                <div class="panel-heading ui-sortable-handle">
                    <h4 class="panel-title">LOG KOREKSI</h4>
                </div>
                <div class="panel-body">
                    <div class="row width-full">
                        <div class="panel-body table-responsive">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th class="width-60">No.</th>
                                        <th>Tanggal</th>
                                        <th>Ket</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pengeluaran->log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr>
                                        <td class="width-60"><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($dt->created_at); ?></td>
                                        <td><?php echo e($dt->ket); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <div id="fullpage" onclick="this.style.display='none';"></div>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    $(function() {
        $('.select2').select2();
    });

    const imgs = document.querySelectorAll('.gallery img');
    const fullPage = document.querySelector('#fullpage');

    imgs.forEach(img => {
        img.addEventListener('click', function() {
            fullPage.style.backgroundImage = 'url(' + img.src + ')';
            fullPage.style.display = 'block';
        });
    });

    function checkFileExtension(id) {
        fileName = document.querySelector('#' + id).value;
        extension = fileName.split('.').pop();
        // if (extension != 'pdf') {
        //     swal({
        //         title: "Warning!!!",
        //         text: "Format Dokument Harus PDF!",
        //         icon: "warning",
        //     });
        //     document.querySelector('#' + id).value = '';
        // }
        const oFile = document.getElementById(id).files[0];
        // alert(oFile.size);

        if (oFile.size > 212000) // 500Kb for bytes.
        {
            swal({
                title: "Warning!!!",
                text: "Besar file maksimal 200 KB!",
                icon: "warning",
            });
            document.querySelector('#' + id).value = '';
        }
        // document.querySelector('.output')
        //     .textContent = extension;
    };
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\inventariss\resources\views/pages/pengeluaran/create.blade.php ENDPATH**/ ?>