

<?php $__env->startSection('title', 'Satuan'); ?>

<?php $__env->startSection('plugins_styles'); ?>
<link href="<?php echo e(asset('assets/vendors/dataTables/datatables.min.css')); ?>" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="#">Manajemen Barang</a></li>
        <li class="breadcrumb-item"><a href="">Laporan</a></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header">Laporan <small>barang...</small></h1>
    <!-- end page-header -->
    <!-- begin row -->
    <div class="panel panel-primary" data-sortable-id="form-stuff-1">
        <!-- begin panel-heading -->
        <?php $namaBulan = array("", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"); ?>
        <div class="panel-heading">
            <div class="row width-full">
                <form method="POST" action="/laporan">
                    <?php echo csrf_field(); ?>
                    <div class="col-lg-12">
                        <div class=" form-inline">
                            <div class="form-group row">
                                <div class="form-inline">
                                    <select class="select2  form-control " name="jenis" data-style="btn-inverse" id="jenis" required>
                                        <option value="">Pilih Jenis Barang</option>
                                        <option value="semua" <?php echo e(('semua'==Session::get('jenis_barang'))?'selected':''); ?>>Semua</option>
                                        <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dt->id); ?>" <?php echo e(($dt->id==Session::get('jenis_barang'))?'selected':''); ?>><?php echo e($dt->jenis); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>&emsp;
                                    <select class="select2  form-control " name="bulan" id="bulan" data-style="btn-inverse" required>
                                        <option value="">Pilih Bulan</option>
                                        <option value="semua" <?php echo e(('semua'==Session::get('bulan'))?'selected':''); ?>>Semua</option>
                                        <?php for($i=1; $i<=12; $i++): ?> <option value="<?php echo e($i); ?>" <?php echo e(($i==Session::get('bulan'))?'selected':''); ?>><?php echo e($namaBulan[$i]); ?></option>
                                            <?php endfor; ?>
                                    </select>&emsp;
                                    <select class="select2  form-control" name="tahun" id="tahun" data-style="btn-inverse" required>

                                        <?php for($i=date('Y'); $i>=2021; $i--): ?> <option value="<?php echo e($i); ?>" <?php echo e(($i==Session::get('tahun'))?'selected':''); ?>><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>&emsp;
                                <!-- <input class="form-control" type="date" name="dtgl">&emsp;
                                <input class="form-control" type="date" name="stgl">&emsp; -->
                                <button class="btn btn-warning"><i class="fa fa-plus"></i> Filter</button>
                            </div>
                        </div>

                    </div>
                </form>
                <form method="POST" action="/laporan/1" target="_blank">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="col-lg-12">
                        <div class=" form-inline">
                            <div class="form-group row">
                                <input type="hidden" name="jenis" value="<?php echo e(Session::get('jenis_barang')); ?>">
                                <input type="hidden" name="bulan" value="<?php echo e(Session::get('bulan')); ?>">
                                <input type="hidden" name="tahun" value="<?php echo e(Session::get('tahun')); ?>">
                                <button class="btn btn-green"><i class="fa fa-print"></i> Cetak</button>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
        </div>
        <div class="panel-body table-responsive">
            <table class="table table-border">
                <thead>
                    <tr align="center">
                        <th class="width-10" rowspan="2">No.</th>
                        <th rowspan="2">JENIS BARANG</th>
                        <th rowspan="2">SATUAN</th>
                        <th colspan="4">JUMLAH</th>
                    </tr>
                    <tr>
                        <th>SALDO AWAL</th>
                        <th>MASUK</th>
                        <th>KELUAR</th>
                        <th>SALDO AKHIR</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $array_barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($loop->iteration); ?></th>
                        <th colspan="7">
                            <?php echo e($dt->jenis); ?>

                        </th>
                    </tr>
                    <?php
                    $total = 0;
                    ?>
                    <?php $__currentLoopData = $dt->barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr align="center">
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($brg->detail->nama); ?></td>
                        <td><?php echo e($brg->detail->satuan_detail->satuan); ?></td>
                        <td><?php echo e($brg->saldo_awal); ?></td>
                        <td><?php echo e($brg->log_masuk); ?></td>
                        <td><?php echo e($brg->log_keluar); ?></td>
                        <td><?php echo e($brg->saldo_awal+$brg->log_masuk-$brg->log_keluar); ?></td>
                    </tr>
                    <?php
                    $total +=($brg->saldo_awal+$brg->log_masuk-$brg->log_keluar);
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr align="center" style="background-color:black">
                        <th colspan="6">TOTAL</th>
                        <th>
                            <?php echo e($total); ?>

                        </th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="panel-footer form-inline">
            <div class="col-md-6 col-lg-10 col-xl-10 col-xs-12">
                <div>
                </div>

            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>
<script src="<?php echo e(asset('assets/vendors/dataTables/datatables.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\inventariss\resources\views/pages/laporan/index.blade.php ENDPATH**/ ?>