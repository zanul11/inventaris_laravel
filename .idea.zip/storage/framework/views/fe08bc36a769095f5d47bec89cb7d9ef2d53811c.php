<html lang="id">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=21cm, initial-scale=1">
    <meta name="description" content="Sistem Informasi Akademik Universitas Mataram">
    <meta name="author" content="Universitas Mataram">
    <title>Cetak LAPORAN AKUNTING</title>
    <link rel="stylesheet" href="<?php echo e(asset('cetak/b.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cetak/f.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cetak/style.css')); ?>">

    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/img/logo.png')); ?>" sizes="16x16">
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/img/logo.png')); ?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('assets/img/logo.png')); ?>">

    <style>

    </style>
</head>

<body class="view mahasiswa halaman" onload="cetak()">
    <div class="container-fluid cetak krs">
        <div class="row">
            <!-- <div id="header">
                <div id="logofakultas">
                    <img src="<?php echo e(asset('assets/img/logo.png')); ?>">
                </div>
                <div id="isi" align="center" style="margin-top: 10px;">
                    <b style="font-size: 16px;">
                        PUSAT PELATIHAN DAN PENGEMBANGAN PROFESI MATARAM (P4M) </b><br>
                    <div style="font-size: 10px;">Jln. Airlangga No.8 Telp. (0370) 631632 Mataram e-mail : p4mmataram@yahoo.com
                    </div>
                    TERAKREDITASI BAN-PNF<br>
                    SK Nomor : 013,14/SKEP/STS-AKR/BAN PNF/XII/2019 <br>

                    <br>
                </div>

            </div> -->
            <!-- <div class="clear" style="margin-top: 0px;">
                <hr style="height:3px;  background-color:black">
            </div> -->
            <center style="margin-top: 10px;">
                <b style="font-size: 16px;">LAPORAN AKUNTING </b><br>
            </center>
            <br>
            <table class="table">
                <tbody>
                    <tr>
                        <td>Jenis </td>
                        <td>:</td>
                        <td><?php echo e($jenis_keuangan); ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Laporan</td>
                        <td>:</td>
                        <td><?php echo e($dTgl); ?> sampai <?php echo e($sTgl); ?></td>
                    </tr>
                    <tr>
                        <td>Kata Kunci</td>
                        <td>:</td>
                        <td><?php echo e($cari??'-'); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
            <b style="font-size: 14px;">DATA LAPORAN AKUNTING </b><br><br>
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Jenis</th>
                        <th>Tanggal</th>
                        <th>Pemasukan</th>
                        <th>Pengeluaran</th>
                        <th>Sub Total</th>
                    </tr>
                </thead>
                <tBody>
                    <?php
                    $total = 0;
                    $pemasukan = 0; $pengeluaran = 0;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php

                    if($dt->jenis==1)
                    $total += $dt->jumlah;
                    else
                    $total -= $dt->jumlah;
                    ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($dt->nama); ?></td>
                        <td><?php echo e($dt->jenis_akunting->jenis); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($dt->tgl))); ?></td>
                        <td><?php echo e(($dt->jenis==1)?number_format($dt->jumlah):0); ?></td>
                        <td><?php echo e(($dt->jenis==0)?number_format($dt->jumlah):0); ?></td>
                        <td><?php echo e(number_format($total)); ?></td>
                    </tr>
                    <?php
                    if($dt->jenis==1)
                    $pemasukan += $dt->jumlah;
                    else
                    $pengeluaran += $dt->jumlah;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tBody>
                <tfoot>
                    <td colspan="4" align="center"><b>Total</b></td>
                    <td><?php echo e(number_format($pemasukan)); ?></td>
                    <td><?php echo e(number_format($pengeluaran)); ?></td>
                    <th><?php echo e(number_format($pemasukan-$pengeluaran)); ?></th>
                </tfoot>
            </table>
            <hr style="height:3px;  background-color:black">



            <!-- <div class="pull-left ttd">
                <br><br><br>Pimpinan P4M,
                <br><br>

                <?php echo '<img src="data:image/png;base64,' . DNS2D::getBarcodePNG('Disahkan oleh Direktur P4M : ', 'QRCODE', 3,3) . '" alt="barcode" />'; ?>


                <br><br>
                <span class="nama">Zanul</span>
            </div> -->



            <div class="pull-right ttd">
                <br>Mataram, <?php echo e(date('d F Y')); ?><br>
                <br>Pembuat,
                <br><br>
                <?php echo '<img src="data:image/png;base64,' . DNS2D::getBarcodePNG('Diterbitkan oleh : '.Auth::user()->nama, 'QRCODE', 3,3) . '" alt="barcode" />'; ?>

                <br><br>
                <span class="nama"><?php echo e(Auth::user()->nama); ?></span>
            </div>
        </div>
        <br>
    </div>

    <script type="text/javascript">
        function cetak() {
            // window.print();
        };
    </script>


</body>

</html><?php /**PATH D:\laragon\www\inventariss\resources\views/pages/laporan_akunting/cetak.blade.php ENDPATH**/ ?>