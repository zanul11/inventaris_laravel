

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('plugins_styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a>Keuangan</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/pemasukan')); ?>">Pemasukan</a></li>
        <li class="breadcrumb-item"><a>Tambah Data</a></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom">TAMBAH DATA</span> PEMASUKAN</h1>


    <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
        <!-- begin panel-heading -->
        <div class="panel-heading ui-sortable-handle">
            <h4 class="panel-title">Form Tambah Data</h4>

        </div>
        <form method="POST" action="<?php echo e(($action=='add')?'/pemasukan':'/pemasukan/'.$pemasukan->id); ?>">
            <?php echo csrf_field(); ?>
            <?php if($action!='add'): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <div class="panel-body">
                <div class="row width-full">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="control-label">Jenis Pemasukan</label>
                            <select class="select2 show-tick form-control required" name="jenis_akunting_id" data-style="btn-primary" required>
                                <option value="">Pilih Jenis Pemasukan</option>
                                <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($dt->id); ?>" <?php echo e((old('jenis_akunting_id',$pemasukan->jenis_akunting_id??'')==$dt->id)?'selected':''); ?>><?php echo e($dt->jenis); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="control-label">Nama Pemasukan</label>
                            <div class="input-group">
                                <input type="text" class="form-control" style="display: block;" value="<?php echo e(old('nama',$pemasukan->nama??'')); ?>" name="nama" placeholder="Nama Pemasukan..." required>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="control-label">Jumlah</label>
                            <div class="input-group">
                                <input type="number" class="form-control" style="display: block;" value="<?php echo e(old('jumlah',$pemasukan->jumlah??'')); ?>" name="jumlah" placeholder="Jumlah/Nilai Pemasukan..." required>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="control-label">Keterangan</label>
                            <div class="input-group">
                                <textarea class="form-control" style="display: block;" value="" name="ket"><?php echo e(old('ket',$pemasukan->ket??'')); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel-footer">
                <input type="submit" value="Simpan" class="btn btn-success m-r-3">
                <a wire:click="batal" class="btn btn-danger">Batal</a>
            </div>
    </div>

    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    $(function() {
        $('.select2').select2();

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\inventariss\resources\views/pages/pemasukan/create.blade.php ENDPATH**/ ?>